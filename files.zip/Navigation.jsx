import logo from "../assets/umbc-logo.png";
import "./Navigation.css";

const links = [
  { label: "Home", href: "/" },
  { label: "FAQ", href: "/faq" },
  { label: "Plans", href: "/plans" },
  { label: "Contact", href: "/contact" },
];

export default function Navigation() {
  return (
    <header className="nav">
      <a href="/" className="nav__logo" aria-label="UMBC home">
        <img src={logo} alt="UMBC" />
      </a>

      <div className="nav__right">
        <nav aria-label="Main">
          <ul className="nav__links">
            {links.map(({ label, href }) => (
              <li key={label}>
                <a href={href}>{label}</a>
              </li>
            ))}
          </ul>
        </nav>

        <a href="/login" className="nav__login">
          Login
        </a>
      </div>
    </header>
  );
}
