import Navigation from "../components/Navigation";

export default function Homepage() {
  return (
    <>
      <Navigation />
      <main>{/* Homepage content goes here */}</main>
    </>
  );
}
